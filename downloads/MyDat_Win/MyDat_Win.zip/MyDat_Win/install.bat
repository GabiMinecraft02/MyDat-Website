@echo off
:: Force l'encodage en UTF-8 pour que les accents s'affichent correctement
chcp 65001 >nul

:: Force le script à se positionner dans le dossier où il est stocké (règle le problème du mode Admin)
cd /d "%~dp0"

:: Vérification des privilèges administrateur
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] Ce script doit être exécuté en tant qu'administrateur.
    echo Clic droit sur 'install.bat' -> 'Exécuter en tant qu'administrateur'.
    echo.
    pause
    exit /b
)

:: Définition des variables
set "TARGET_DIR=C:\Program Files\mydat"
set "FILENAME=mydat.exe"

echo ===================================================
echo               INSTALLATION DE MYDAT
echo ===================================================
echo.

echo [1/2] Création du dossier de destination...
if not exist "%TARGET_DIR%" (
    mkdir "%TARGET_DIR%"
    echo Dossier créé : %TARGET_DIR%
) else (
    echo Le dossier existe déjà.
)
echo.

echo [2/2] Déplacement du fichier...
if exist "%FILENAME%" (
    move /y "%FILENAME%" "%TARGET_DIR%\"
    echo.
    echo [SUCCÈS] %FILENAME% a été installé avec succès dans :
    echo          %TARGET_DIR%
) else (
    echo.
    echo [ERREUR] Le fichier "%FILENAME%" est introuvable.
    echo Assurez-vous qu'il est bien situé dans le même dossier que ce script.
    echo Dossier de recherche actuel : %cd%
)
echo.
echo ===================================================
pause