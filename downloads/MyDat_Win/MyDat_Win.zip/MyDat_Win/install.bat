@echo off
:: Vérifie les droits Administrateur
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Erreur : Ce script doit être exécuté en tant qu'Administrateur.
    echo Clic droit sur 'install.bat' -> 'Exécuter en tant qu'administrateur'.
    pause
    exit /b 1
)

echo [*] Installation de mydat sur Windows...

:: Définir le dossier d'installation
set "INSTALL_DIR=C:\Program Files\mydat"

:: Créer le dossier s'il n'existe pas
if not exist "%INSTALL_DIR%" (
    mkdir "%INSTALL_DIR%"
)

:: Copier l'exécutable
if exist "dist\mydat.exe" (
    copy /Y "dist\mydat.exe" "%INSTALL_DIR%\mydat.exe" >nul
) else (
    echo [!] Erreur : Le fichier dist\mydat.exe est introuvable. Lancez d'abord build.bat.
    pause
    exit /b 1
)

:: Ajouter au PATH utilisateur (si pas déjà présent)
echo %PATH% | findstr /I /C:"%INSTALL_DIR%" >nul
if %errorlevel% neq 0 (
    echo [*] Ajout de mydat au PATH système...
    setx /M PATH "%PATH%;%INSTALL_DIR%"
)

echo [+=+] Installation réussie ! Redémarrez votre terminal et tapez 'mydat'.
pause