#!/bin/bash

# Vérifie si l'utilisateur est root/sudo
if [ "$EUID" -ne 0 ]; then
  echo "[!] Erreur : Veuillez exécuter ce script avec sudo : sudo ./install_linux.sh"
  exit 1
fi

echo "[*] Installation de mydat sur Linux..."

if [ -f "dist/mydat" ]; then
    # Copie vers le dossier des binaires locaux
    cp dist/mydat /usr/local/bin/mydat
    # Donne les droits d'exécution
    chmod +x /usr/local/bin/mydat
    echo "[+=+] Installation réussie ! Vous pouvez maintenant utiliser la commande 'mydat'."
else
    echo "[!] Erreur : Le fichier dist/mydat est introuvable. Veuillez compiler le projet d'abord."
    exit 1
fi