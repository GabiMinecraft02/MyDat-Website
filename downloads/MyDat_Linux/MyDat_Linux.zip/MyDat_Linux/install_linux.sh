#!/bin/bash

TARGET_DIR="/opt/mydat"
FILENAME="mydat"

echo "[1/2] Création du dossier de destination..."
sudo mkdir -p "$TARGET_DIR"

echo "[2/2] Déplacement et configuration du fichier..."
if [ -f "$FILENAME" ]; then
    sudo mv "$FILENAME" "$TARGET_DIR/"
    sudo chmod +x "$TARGET_DIR/$FILENAME"
    echo "[SUCCÈS] $FILENAME a été installé avec succès dans $TARGET_DIR."
else
    echo "[ERREUR] Le fichier $FILENAME est introuvable dans le dossier actuel."
    exit 1
fi