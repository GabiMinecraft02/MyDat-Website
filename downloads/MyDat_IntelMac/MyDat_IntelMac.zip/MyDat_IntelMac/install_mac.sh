#!/bin/bash

TARGET_DIR="/Applications/mydat"
echo "[1/2] Création du dossier de destination..."
sudo mkdir -p "$TARGET_DIR"

echo "[2/2] Recherche de l'exécutable compatible..."

if [ -f "mydat_apple" ]; then
    echo "Fichier détecté : mydat_apple (Apple Silicon)"
    SOURCE_FILE="mydat_apple"
elif [ -f "mydat_intel" ]; then
    echo "Fichier détecté : mydat_intel (Intel)"
    SOURCE_FILE="mydat_intel"
else
    echo "[ERREUR] Ni 'mydat_apple' ni 'mydat_intel' n'a été trouvé dans le dossier actuel."
    exit 1
fi

# Déplacement et renommage en "mydat"
sudo mv "$SOURCE_FILE" "$TARGET_DIR/mydat"
sudo chmod +x "$TARGET_DIR/mydat"

echo "[SUCCÈS] Installé avec succès sous le nom 'mydat' dans $TARGET_DIR."