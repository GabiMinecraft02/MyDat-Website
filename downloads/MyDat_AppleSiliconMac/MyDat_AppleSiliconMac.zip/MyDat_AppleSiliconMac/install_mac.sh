#!/bin/bash

# Vérifie les privilèges sudo
if [ "$EUID" -ne 0 ]; then
  echo "[!] Erreur : Veuillez exécuter ce script avec sudo : sudo ./install_mac.sh"
  exit 1
fi

echo "[*] Installation de mydat sur macOS..."

# Détection de l'architecture du Mac
ARCH=$(uname -m)

if [ "$ARCH" = "arm64" ]; then
    echo "[*] Architecture Apple Silicon détectée (M1/M2/M3/M4)"
    BIN_SOURCE="dist/mydat_apple"
else
    echo "[*] Architecture Intel détectée"
    BIN_SOURCE="dist/mydat_intel"
fi

if [ -f "$BIN_SOURCE" ]; then
    # S'assurer que le dossier de destination existe
    mkdir -p /usr/local/bin
    
    # Copie et droits
    cp "$BIN_SOURCE" /usr/local/bin/mydat
    chmod +x /usr/local/bin/mydat
    echo "[+=+] Installation réussie ! Vous pouvez maintenant utiliser la commande 'mydat'."
else
    echo "[!] Erreur : Le fichier binaire ($BIN_SOURCE) est introuvable. Veuillez compiler le projet d'abord."
    exit 1
fi